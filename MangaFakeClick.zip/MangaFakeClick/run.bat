@echo off
rem Create virtual environment if it doesn't exist
if not exist ".venv" (
    python -m venv .venv
)

rem Activate virtual environment
call .venv\Scripts\activate.bat

rem Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

rem Run the script
python main.py %*
