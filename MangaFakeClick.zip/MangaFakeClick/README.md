# Manga Fake Click Utility

This repository provides a minimal Python utility that:

1. **Performs a mouse click** at an exact screen coordinate (1:1 with the original action).
2. **Executes a fake HTTP transaction** (e.g., a GET request) to simulate a network call.

Both actions are driven by a simple `config.json` file, but you can also override them via command‑line arguments.

## Files

- `requirements.txt` – Python dependencies (`pyautogui`, `requests`).
- `config.json` – Default configuration (click coordinates, delay, and transaction details).
- `main.py` – Core script that reads the config, performs the click, and runs the fake transaction.
- `run.bat` – Convenience batch file to create a virtual environment, install dependencies, and launch the script.
- `README.md` – This file.

## Quick start (Windows PowerShell / CMD)

```powershell
cd C:\Users\User\.gemini\antigravity\scratch\MangaFakeClick
.\.venv\Scripts\Activate.ps1   # PowerShell (or activate.bat for CMD)
pip install -r requirements.txt
python main.py
```

Or simply double‑click `run.bat`.

## Customisation

### Edit `config.json`
```json
{
  "click": {
    "x": 500,
    "y": 300,
    "delay": 0.1
  },
  "transaction": {
    "url": "https://httpbin.org/get",
    "method": "GET",
    "payload": {}
  }
}
```
- Change `x`/`y` to the screen coordinates you need.
- Adjust `delay` (seconds) to mimic the exact timing of the original click.
- Replace the `url`, `method`, or `payload` to match the original network request.

### Command‑line overrides
You can pass arguments to `main.py` to temporarily override the config without editing the file:

```powershell
python main.py --x 600 --y 400 --url https://example.com/api --method POST --payload '{"key":"value"}'
```

### Packaging as a standalone executable (optional)
If you prefer a single `.exe` file, install `pyinstaller` and run:

```powershell
pip install pyinstaller
pyinstaller --onefile main.py
```
The resulting `dist\main.exe` can be distributed and run on any Windows machine (no Python needed).

---

Feel free to modify the script or add more functionality (e.g., multiple clicks, random jitter, logging). If you need additional features, just let me know!
