import json
import time
import argparse
import pyautogui
import requests
from pathlib import Path

def load_config(path: str = "config.json"):
    cfg_path = Path(path)
    if cfg_path.is_file():
        with cfg_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    else:
        return {}

def perform_click(x: int, y: int, delay: float = 0.1):
    """Move to (x, y) and click.
    Parameters
    ----------
    x, y: screen coordinates
    delay: seconds to wait after moving before clicking
    """
    pyautogui.moveTo(x, y, duration=0.2)
    time.sleep(delay)
    pyautogui.click()
    print(f"Clicked at ({x}, {y}) with delay {delay}s")

def fake_transaction(url: str, method: str = "GET", payload: dict | None = None):
    """Send a dummy HTTP request to mimic a transaction.
    Returns the response status code.
    """
    try:
        if method.upper() == "GET":
            r = requests.get(url, timeout=5)
        elif method.upper() == "POST":
            r = requests.post(url, json=payload or {}, timeout=5)
        else:
            raise ValueError(f"Unsupported method: {method}")
        print(f"Fake transaction {method.upper()} {url} -> {r.status_code}")
        return r.status_code
    except Exception as e:
        print(f"Fake transaction failed: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Manga Fake Click Utility – perform a 1:1 click and a fake HTTP transaction.")
    parser.add_argument("--x", type=int, help="X coordinate for the click (overrides config)")
    parser.add_argument("--y", type=int, help="Y coordinate for the click (overrides config)")
    parser.add_argument("--delay", type=float, help="Delay after moving before click (seconds)")
    parser.add_argument("--url", type=str, help="URL for the fake transaction (overrides config)")
    parser.add_argument("--method", type=str, choices=["GET", "POST"], help="HTTP method for the fake transaction")
    parser.add_argument("--payload", type=str, help="JSON payload for POST requests (as a JSON string)")
    args = parser.parse_args()

    cfg = load_config()
    # Resolve click parameters
    click_cfg = cfg.get("click", {})
    x = args.x if args.x is not None else click_cfg.get("x", 0)
    y = args.y if args.y is not None else click_cfg.get("y", 0)
    delay = args.delay if args.delay is not None else click_cfg.get("delay", 0.1)
    # Resolve transaction parameters
    txn_cfg = cfg.get("transaction", {})
    url = args.url if args.url is not None else txn_cfg.get("url", "")
    method = args.method if args.method is not None else txn_cfg.get("method", "GET")
    payload = None
    if args.payload:
        try:
            payload = json.loads(args.payload)
        except json.JSONDecodeError:
            print("Invalid JSON payload provided via --payload; ignoring payload.")
    else:
        payload = txn_cfg.get("payload")

    # Perform actions
    if x and y:
        perform_click(x, y, delay)
    else:
        print("Click coordinates not provided; skipping click.")

    if url:
        fake_transaction(url, method, payload)
    else:
        print("Transaction URL not provided; skipping fake transaction.")

if __name__ == "__main__":
    main()
